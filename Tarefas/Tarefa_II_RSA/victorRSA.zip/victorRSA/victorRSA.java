/*
				Victor Dallagnol Bento
				Segurança de Rede
				Algoritmo RSA (Rivest–Shamir–Adleman)

				Para executar:
					javac victorRSA.java
					java victorRSA

*/


import java.math.*;
import java.security.*;
import java.util.Scanner;

public class victorRSA{
//==================================	Atributos 	
	private int pubkey;
	private int bitlen = 255;
	private BigInteger p, q, n, d, e, m;
	private String msgcifrada, msgdecifrada;
    public static Scanner scan;

//==================================	Gerador de bits aleatórios usados para selecionar candidatos a serem testados para primalidade
	SecureRandom r = new SecureRandom();

//==================================	RSA Calculo
	public void rsa(){
		this.p = new BigInteger(bitlen / 2, 100, r);
		this.q = new BigInteger(bitlen / 2, 100, r);
		this.n = this.p.multiply(q);	// Compute n = p * q
		this.m = (this.p.subtract(BigInteger.ONE)).multiply(this.q.subtract(BigInteger.ONE));	// Compute a função totiente phi(n) = (p -1) (q -1)
		e = new BigInteger("3");	//	Escolha um inteiro  "e"  , 1 < "e" < phi(n) ,  "e" e phi(n) sejam primos entre si.
		while(m.gcd(e).intValue() > 1)
			e = e.add(new BigInteger("2"));
		d = e.modInverse(m);	// d seja inverso multiplicativo de "e"
	}

//==================================	mensagem cifrada - RSA_encrypt()
    private String RSA_encrypt(String msg, BigInteger e, BigInteger n) {
    	this.msgcifrada = new BigInteger(msg.getBytes()).modPow(e, n).toString();
        return msgcifrada;
    }   

//==================================	mensagem decifrada - RSA_decrypt()
	private String RSA_decrypt(String msg, BigInteger d, BigInteger n) {
    	this.msgdecifrada = new String(new BigInteger(msg).modPow(d, n).toByteArray());
    	return msgdecifrada;
    }

//==================================	Permite acesso a alguns atributos
	private BigInteger get_p(){
		return this.p;
	}
	private BigInteger get_q(){
		return this.q;
	}
	private BigInteger get_e(){
		return this.e;
	}
	private BigInteger get_n(){
		return this.n;
	}
	private BigInteger get_d(){
		return this.d;
	}

//==================================	Print dos atributos
	private void prints(){
		System.out.println();
		System.out.println("p:\t"+this.p);
        System.out.println("q:\t"+this.q);
        System.out.println("n:\t"+this.n);
        System.out.println("e:\t"+this.e);
        System.out.println("d:\t"+this.d+"\n");
	}


//==================================	Função principal MAIN
	public static void main(String[] args) {
		System.out.println("\t\t=====================================");
		System.out.println("\t\tAlgorithm RSA (Rivest–Shamir–Adleman)");
		System.out.println("\t\t=====================================\n");
		System.out.println("Digite a mensagem a ser criptografada:");
        
        scan = new Scanner(System.in);	//	Objeto de Scanner para leitura da mensagem
        String msg = scan.nextLine();	//	Lê mensagem digitada
        System.out.println("\n<!>\tMensagem original: " + msg);
		
		victorRSA one = new victorRSA();	// one é um objeto para a classe victorRSM
		one.rsa();	//	Calcula RSA
//		one.prints();

		String msgcifrada_, msgdecifrada_;
		msgcifrada_ = one.RSA_encrypt(msg, one.get_e(), one.get_n());	// Cifra mensagem
		msgdecifrada_ = one.RSA_decrypt(msgcifrada_, one.get_d(), one.get_n());		// Decifra mensagem
		
		System.out.println("<?>\tMensagem cifrada: " + msgcifrada_);
        System.out.println("<!>\tMensagem decifrada: " + msgdecifrada_);		
	}

}